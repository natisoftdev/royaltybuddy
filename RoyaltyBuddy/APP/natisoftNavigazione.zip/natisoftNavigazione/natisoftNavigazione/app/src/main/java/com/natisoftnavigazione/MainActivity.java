package com.natisoftnavigazione;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.webkit.DownloadListener;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import com.utility.Avvisi;
import android.webkit.JavascriptInterface;
import android.preference.PreferenceManager;
import android.provider.MediaStore;


@SuppressLint("SetJavaScriptEnabled")
public class MainActivity extends Activity implements NavigationDrawerFragment.NavigationDrawerCallbacks  {

	private ValueCallback<Uri[]> mUploadMessage2;
	private final static int FILECHOOSER_RESULTCODE = 222;
	private static final int INPUT_FILE_REQUEST_CODE = 222;
	private String mCameraPhotoPath;
	private Activity ActivityMain;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.getWindow().requestFeature(Window.FEATURE_PROGRESS);
		this.getWindow().setFeatureInt(Window.FEATURE_PROGRESS, Window.PROGRESS_VISIBILITY_ON);
		ActivityMain = this;
		setContentView(R.layout.activity_main);
	}

	@Override
	protected void onResume() {
		super.onResume();
	}

	@Override
	protected void onPause() {
		super.onPause();
		try
		{
			NavigazioneFragment frm = (NavigazioneFragment) getFragmentManager().findFragmentByTag("position"+0);
			WebView webView = frm.getWebView();
			if(webView!=null)
				webView.loadUrl("javascript:stopThreads()");
		}
		catch(Exception ex)
		{
			Log.d(this.getClass().getSimpleName(), "javascript:stopThreads()", ex);
		}
	}

	public void onBackPressed()	{ Avvisi.avvisoMSG( this, getString(R.string.backMessage), getString(R.string.avviso)); }

	@Override
	public void onNavigationDrawerItemSelected(int position)
	{
		Fragment frm = null;
		frm = getFragmentManager().findFragmentByTag("position"+position);
		if(frm==null)
		{
			if(position==0)
			{
				frm = NavigazioneFragment.newInstance(position + 1);
				frm.setRetainInstance(true);
			}
			else  if(position==1)
			{
				frm = ImpostazioniFragment.newInstance(position + 1);
				frm.setRetainInstance(true);
			}
		}
		FragmentManager fragmentManager = getFragmentManager();
		fragmentManager.beginTransaction().replace(R.id.container, frm, "position"+position ).commit();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);

        SharedPreferences sharedPrefs = PreferenceManager.getDefaultSharedPreferences(this);
        int livCompress = sharedPrefs.getInt("livCompress", 20);
		if(requestCode==FILECHOOSER_RESULTCODE)
		{
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {

				if (requestCode != INPUT_FILE_REQUEST_CODE || mUploadMessage2 == null) {
					super.onActivityResult(requestCode, resultCode, data);
					return;
				}

				Uri[] results = null;
				String uri_canc = "";
				// Check that the response is a good one
				if (resultCode == Activity.RESULT_OK) {
					if (data == null) {
						// If there is not data, then we may have taken a photo
						if (mCameraPhotoPath != null) {
							results = new Uri[]{Uri.parse(mCameraPhotoPath)};
							uri_canc  = mCameraPhotoPath;
						}
					} else {
						String dataString = data.getDataString();
						if (dataString != null) {
							results = new Uri[]{Uri.parse(dataString)};
							uri_canc  = dataString;
						}
					}
				}


				try {
					InputStream ims = getContentResolver().openInputStream( Uri.parse(uri_canc) );
					Bitmap bitmap = BitmapFactory.decodeStream(ims);
					if(bitmap!=null) {
						File storageDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
						Calendar cal = Calendar.getInstance();
						String extTmpFile = ".jpg";
						String nameTmpFile = "img_compress_" + cal.getTimeInMillis();
						File outputFile = File.createTempFile(nameTmpFile, extTmpFile, storageDir);
						OutputStream os = new FileOutputStream(outputFile);
						bitmap.compress(Bitmap.CompressFormat.JPEG, livCompress, os);
						os.flush();
						os.close();
						Uri ut = Uri.fromFile(outputFile);
						results = new Uri[]{ut};
					}

				} catch (Exception e) {
					Log.d("onActivityResult - comp", ""+e);
					e.printStackTrace();
				}


				mUploadMessage2.onReceiveValue(results);
				mUploadMessage2 = null;
			}
		}
		else if(requestCode==IntentIntegrator.REQUEST_CODE)
		{
			IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);

			if(result.getContents() != null)
			{
				String ris = result.getContents();
				NavigazioneFragment frm = (NavigazioneFragment) getFragmentManager().findFragmentByTag("position"+0);
				WebView webView = frm.getWebView();

				if(webView!=null)
					webView.loadUrl("javascript:callBackLetturaQR('"+ris+"')");
			}
		}
		else
		{
			super.onActivityResult(requestCode, resultCode, data);
		}
	}

	public static class NavigazioneFragment extends Fragment {
		public static final String ARG_PLANET_NUMBER = "section_number";

		WebView webView;
		View rootView;

		public static NavigazioneFragment newInstance(int sectionNumber) {

			NavigazioneFragment fragment = new NavigazioneFragment();
			Bundle args = new Bundle();
			args.putInt(ARG_PLANET_NUMBER, sectionNumber);
			fragment.setArguments(args);
			return fragment;
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

			if(rootView==null)
			{
				rootView = inflater.inflate(R.layout.fragment_web_navigazione, container, false);
				webView = rootView.findViewById(R.id.webView1);
				webView.clearSslPreferences();
				WebSettings webSettings = webView.getSettings();
				webSettings.setJavaScriptEnabled(true);
				webSettings.setSupportZoom(false);
				webSettings.setDefaultTextEncodingName("");
				webView.setWebChromeClient(
						new WebChromeClient() {

							public void onProgressChanged(WebView view, int progress) {
								try {
									MainActivity x = (MainActivity) getActivity();

									x.setTitle("Loading...");
									x.setProgress(progress * 100);

								} catch (Exception ex) {
									//Log.d("WebChromeClient - onProgressChanged", "errore :"+ex);
								}
							}

							// For Android 5.0
							public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> filePath, WebChromeClient.FileChooserParams fileChooserParams) {

								MainActivity mainActivity = ((MainActivity) getActivity());

								// Double check that we don't have any existing callbacks
								if (mainActivity.mUploadMessage2 != null) {
									mainActivity.mUploadMessage2.onReceiveValue(null);
								}

								mainActivity.mUploadMessage2 = filePath;
								Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

								if (takePictureIntent.resolveActivity(mainActivity.getPackageManager()) != null)
								{
									// Create the File where the photo should go
									File photoFile = null;
									try {
										photoFile = createImageFile();
										takePictureIntent.putExtra("PhotoPath", mainActivity.mCameraPhotoPath);
									} catch (IOException ex) {
										// Error occurred while creating the File
										Log.d("onShowFileChooser", "Unable to create Image File", ex);
									}

									// Continue only if the File was successfully created
									if (photoFile != null) {
										mainActivity.mCameraPhotoPath = "file:" + photoFile.getAbsolutePath();
										takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT,
												Uri.fromFile(photoFile));
									} else {
										takePictureIntent = null;
									}
								}

								Intent contentSelectionIntent = new Intent(Intent.ACTION_GET_CONTENT);
								contentSelectionIntent.addCategory(Intent.CATEGORY_OPENABLE);
								contentSelectionIntent.setType("image/*");

								Intent[] intentArray;
								if (takePictureIntent != null) {
									intentArray = new Intent[]{takePictureIntent};
								} else {
									intentArray = new Intent[0];
								}

								Intent chooserIntent = new Intent(Intent.ACTION_CHOOSER);
								chooserIntent.putExtra(Intent.EXTRA_INTENT, contentSelectionIntent);
								chooserIntent.putExtra(Intent.EXTRA_TITLE, "Image Chooser");
								chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, intentArray);
								mainActivity.startActivityForResult(chooserIntent, ((MainActivity) getActivity()).INPUT_FILE_REQUEST_CODE);

								return true;
							}

							private File createImageFile() throws IOException {
								// Create an image file name
								String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
								String imageFileName = "JPEG_" + timeStamp + "_";
								File storageDir = Environment.getExternalStoragePublicDirectory(
										Environment.DIRECTORY_PICTURES);

								File imageFile = File.createTempFile(
										imageFileName,  /* prefix */
										".jpg",         /* suffix */
										storageDir      /* directory */
								);
								return imageFile;
							}
						});

				webView.setWebViewClient(new WebViewClient() {
					@Override
					public boolean shouldOverrideUrlLoading(WebView view, String url) {
						if (url.startsWith("tel:")) {
							Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse(url));
							startActivity(intent);
						}
						else if (url.startsWith("mailto:")) {
							Intent mail = new Intent(Intent.ACTION_SEND);
							mail.setType("application/octet-stream");
							mail.putExtra(Intent.EXTRA_EMAIL, R.string.send_email);
							mail.putExtra(Intent.EXTRA_SUBJECT, R.string.send_subject);
							mail.putExtra(Intent.EXTRA_TEXT, R.string.send_text);
							startActivity(mail);
						}
						else if (url.startsWith("http:") || url.startsWith("https:")) {
							view.loadUrl(url);
						}
						return true;
					}
				});


				webView.setDownloadListener(new DownloadListener() {
					public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {
						Uri uri = Uri.parse(url);
						Intent intent = new Intent(Intent.ACTION_VIEW, uri);
						startActivity(intent);
					}
				});

				webView.getSettings().setJavaScriptEnabled(true);
				JavaScriptInterface JSInterface = new JavaScriptInterface( getActivity() );
				webView.addJavascriptInterface(JSInterface, "JSInterface");
				init();
			}

			return rootView;
		}

		public void init(){webView.loadUrl(getString(R.string.url));}

		public WebView getWebView()
		{
			return webView;
		}

		public class JavaScriptInterface {
			Context mContext;

			/** Instantiate the interface and set the context */
			JavaScriptInterface(Context c) {
				mContext = c;
			}

			@JavascriptInterface
			public void disattivaRotazione(){getActivity().setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_NOSENSOR);}

			@JavascriptInterface
			public void attivaRotazione(){getActivity().setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR);}

			@JavascriptInterface
			public void avviaGoogleMaps(String lat, String lng, String label) //lat e lng devono essere float (usare il punto e non la virgola)
			{
				Uri gmmIntentUri = Uri.parse("geo:0,0?q="+lat+","+lng+"("+label+")");
				Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
				mapIntent.setPackage("com.google.android.apps.maps");
				startActivity(mapIntent);
			}
		}
	}


	public static class ImpostazioniFragment extends Fragment {

		public static final String ARG_PLANET_NUMBER = "section_number";

		public static ImpostazioniFragment newInstance(int sectionNumber) {
			ImpostazioniFragment fragment = new ImpostazioniFragment();
			Bundle args = new Bundle();
			args.putInt(ARG_PLANET_NUMBER, sectionNumber);
			fragment.setArguments(args);
			return fragment;
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
			View rootView = inflater.inflate(R.layout.fragment_impostazioni, container, false);
			return rootView;
		}
	}
}