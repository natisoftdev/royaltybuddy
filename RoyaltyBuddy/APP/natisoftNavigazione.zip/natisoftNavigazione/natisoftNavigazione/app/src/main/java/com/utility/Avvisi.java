package com.utility;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.widget.Toast;

public class Avvisi 
{
	public static void avvisoMSG(final Context context, final String msg, String tipo)
	{
		SharedPreferences sharedPrefs = PreferenceManager.getDefaultSharedPreferences(context);
		((Activity)context).runOnUiThread(new Runnable() {public void run() {Toast.makeText(context, msg, Toast.LENGTH_SHORT).show();}});
	}
}